package com.sen.vunahub.VunaHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VunaHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
